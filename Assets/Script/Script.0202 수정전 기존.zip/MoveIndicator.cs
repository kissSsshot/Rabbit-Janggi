using UnityEngine;

public class MoveIndicator : MonoBehaviour
{
    public Vector2Int targetPosition;
    public Rabbit rabbit;

    void OnMouseDown()
    {
        if (GameManager.Instance.isGameOver) return;
        if (GameManager.Instance.IsInMenu) return;
        if (rabbit != null)
        {
            rabbit.MoveTo(targetPosition);
        }
    }
}
