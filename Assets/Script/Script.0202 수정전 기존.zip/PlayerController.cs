using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public Rabbit rabbit;  // 이동할 토끼

    void Update()
    {
        
    }
}
