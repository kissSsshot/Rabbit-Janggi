using UnityEngine;

public class KingRabbit : Rabbit
{
    
    protected override void Start()
    {
        base.Start(); // Rabbit의 Start 호출
        /*if (team == Team.White)
        transform.position = GridManager.Instance.GridToWorld(new Vector2Int(-4, 4));
        else
        transform.position = GridManager.Instance.GridToWorld(new Vector2Int(4, -4));*/ // 위치 테스트용
    }
    

    public override void MoveTo(Vector2Int newPosition)
    {
        base.MoveTo(newPosition); // 기본 이동 로직 수행( 말 이동 + 턴 전환)

        // 이동 후 승리 조건 확인 전에 로그 찍기
        Vector3 kingWorldPos = transform.position;
        Vector3 targetGoal = (team == Team.White) 
            ? new Vector3(-3f, 3.5f, 0f) 
            : new Vector3(3f, -3.5f, 0f);

        float dist = Vector3.Distance(kingWorldPos, targetGoal);
        Debug.Log($"{team} 왕 현재 위치: {kingWorldPos}, 목표 위치: {targetGoal}, 거리: {dist}");

        // 이동 후 승리 조건 확인
        if (GameManager.Instance.CheckWinCondition(this.team))
        {
            Debug.Log(team + " 팀 왕토끼 승리 조건 충족!");
            GameManager.Instance.EndGame(team);
        }
    }
}