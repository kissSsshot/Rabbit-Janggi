using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;
using System.Collections;

public class TurnControlUI : MonoBehaviour
{
    [Header("Game UI")]
    public Button stopButton;
    public TMP_Text gameOverText;
    public GameObject gameOverPanel;
    public TMP_Text turnText;

    [Header("Panels")]
    public GameObject startPanel;   // 시작화면 패널 (ON at boot)
    public GameObject gamePanel;    // 게임 패널 (OFF at boot)

    [Header("Optional Fade")]
    public CanvasGroup fadeCanvasGroup; // 페이드용
    public float fadeDuration = 0.25f;

    void Start()
    {
        // 시작화면 초기화
        startPanel?.SetActive(true);
        gamePanel?.SetActive(false);

        gameOverPanel?.SetActive(false);

        // 메뉴 상태 진입(정지 + 기본턴 알림)
        GameManager.Instance.EnterMenu();

        // 턴 텍스트 이벤트
        UpdateTurnText(GameManager.Instance.currentTurn);
        GameManager.OnTurnChanged += UpdateTurnText;

        gameOverPanel?.SetActive(false); // 게임 오버 UI 숨기기
        UpdateTurnText(GameManager.Instance.currentTurn);  // 턴 UI 초기화
        GameManager.OnTurnChanged += UpdateTurnText; // 턴 변경 이벤트 등록

        if (startPanel) startPanel.SetActive(true);
        if (gamePanel)  gamePanel.SetActive(false);
        if (gameOverPanel) gameOverPanel.SetActive(false); // null이면 스킵
    }

    public void OnStartButtonPressed() // 게임 시작 버튼
    {
        GameManager.Instance.StartGameFromMenu();
        if (startPanel) startPanel.SetActive(false);
        if (gamePanel)  gamePanel.SetActive(true);
    }

    public void OnStopButtonPressed() // 턴 종료(넘기기) 버튼
    {
        MoveIndicatorManager.Instance.ClearAll(); // 빨간 점 먼저 제거

        if (GameManager.Instance.IsJumpChainActive) // 점프 체인 있을때만 적용
        {
            GameManager.Instance.EndJumpChain();
            GameManager.Instance.SwitchTurn();

            foreach (var rabbit in FindObjectsOfType<Rabbit>()) // 애니메이터 Idle 상태로 리셋
            {
                var anim = rabbit.GetComponentInChildren<Animator>();
                if (anim != null)
                {
                    anim.SetFloat("moveX", 0f);
                    anim.SetFloat("moveY", 0f);
                }
            }
        }
    }

    public void OnRestartButtonPressed() // 재시작 버튼
    {
        MoveIndicatorManager.Instance.ClearAll();
    GameManager.Instance.EnterMenu();
    if (gameOverPanel) gameOverPanel.SetActive(false);
    if (startPanel) startPanel.SetActive(true);
    if (gamePanel)  gamePanel.SetActive(false);
    }

    public void OnExitButtonPressed() // 종료 버튼
    {
        Application.Quit();
        #if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
        #endif
    }

    public void ShowWinPanel(Team winner)
    {
        if (gameOverText) gameOverText.text = $"{winner} 팀 승리!";
        if (gameOverPanel) gameOverPanel.SetActive(true);
        else Debug.LogWarning("GameOverPanel이 연결되지 않았습니다.");
    }

    private void UpdateTurnText(Team currentTeam)
    {
        /*if (turnText == null) return;

        turnText.text = (currentTeam == Team.White) ? "White 턴입니다" : "Black 턴입니다";
        turnText.color = (currentTeam == Team.White) ? Color.white : Color.black;

        // Stop 버튼은 점프 체인일 때만 활성화
        if (stopButton != null)
            stopButton.interactable = GameManager.Instance.IsJumpChainActive;*/

        Debug.Log("턴 UI 업데이트: " + currentTeam);
        if (turnText == null)
        {
            Debug.LogWarning("TurnText가 연결되지 않았습니다!");
            return;
        }

        turnText.text = (currentTeam == Team.White) ? "White's Trun" : "Black's Turn";
        turnText.color = (currentTeam == Team.White) ? Color.white : Color.black;
    }

    private void OnDestroy()
    {
        GameManager.OnTurnChanged -= UpdateTurnText; // 메모리 누수 방지
    }

}
