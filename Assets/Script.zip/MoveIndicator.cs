using UnityEngine;

public class MoveIndicator : MonoBehaviour
{
    public Vector2Int targetPosition;
    public Rabbit rabbit;

    void OnMouseDown()
    {
        if (GameManager.Instance.isGameOver) return; // 게임 오버 시 무시
        if (GameManager.Instance.IsInMenu) return; // 메뉴일 땐 이동 불가
        if (rabbit != null)
        {
            rabbit.MoveTo(targetPosition); // 토끼 이동 실행
        }
    }
}
