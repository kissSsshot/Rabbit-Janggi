using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    public Team currentTurn = Team.White;
    public GridManager gridManager;

    public bool isMenu = true; 
    public bool IsInMenu => isMenu;

    public KingRabbit kingRabbitWhite;
    public KingRabbit kingRabbitBlack;

    public Vector2Int whiteGoal = new Vector2Int(-3, 3);   // 검정 진영 중앙
    public Vector2Int blackGoal = new Vector2Int(3, -3);   // 흰 진영 중앙

    private Vector2Int whiteStartCenter; // 화이트 왕의 '시작' 그리드 좌표
    private Vector2Int blackStartCenter; // 블랙  왕의 '시작' 그리드 좌표

    public static event System.Action<Team> OnTurnChanged;

    public bool isGameOver = false;
    public bool IsJumpChainActive { get; private set; } = false;
    private Rabbit jumpChainRabbit = null;

    void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);

        gridManager = FindObjectOfType<GridManager>();

        // 자동으로 왕토끼 참조 연결
        if (!kingRabbitWhite || !kingRabbitBlack)
        {
            foreach (KingRabbit king in FindObjectsOfType<KingRabbit>())
            {
                if (king.team == Team.White) kingRabbitWhite = king;
                else if (king.team == Team.Black) kingRabbitBlack = king;
            }
        }
    }

    void Start()
    {
        RefreshKings(); // Awake 다음에 한 번 더 보정
        whiteStartCenter = gridManager.GetGridIndex(kingRabbitWhite.transform.position);
        blackStartCenter = gridManager.GetGridIndex(kingRabbitBlack.transform.position);
    }

    // 비활성 포함해서 킹 다시 찾기 (Unity 버전에 맞게 컴파일 분기)
    private void RefreshKings()
    {
    #if UNITY_600_OR_NEWER
        var kings = FindObjectsByType<KingRabbit>(FindObjectsInactive.Include, FindObjectsSortMode.None);
    #else
        var kings = FindObjectsOfType<KingRabbit>(true);
    #endif
        foreach (var k in kings)
        {
        if (k.team == Team.White) kingRabbitWhite = k;
        else if (k.team == Team.Black) kingRabbitBlack = k;
        }
    }

    public void EnterMenu()
    {
        isMenu = true;
        isGameOver = false;

        // 기본 턴/상태 초기화
        currentTurn = Team.White;
        OnTurnChanged?.Invoke(currentTurn);

        // 입력/애니 정지
        Time.timeScale = 0f;

        // 보드/턴 리셋 훅
        // FindObjectOfType<MoveIndicatorManager>()?.ClearAll();
        // FindObjectOfType<TurnManager>()?.ResetTurn();
        // FindObjectOfType<BoardManager>()?.ResetBoard();
    }

    public void StartGameFromMenu()
    {
        isMenu = false;
        isGameOver = false;
        Time.timeScale = 1f;

        // 첫 턴 세팅/하이라이트 갱신 등
        OnTurnChanged?.Invoke(currentTurn);
        // FindObjectOfType<TurnManager>()?.BeginFirstTurn();
    }

    public void SwitchTurn()
    {
        currentTurn = (currentTurn == Team.White) ? Team.Black : Team.White;
        Debug.Log("현재 턴: " + currentTurn);
        OnTurnChanged?.Invoke(currentTurn);

        CheckVictoryAfterTurn();
    }

    public void StartJumpChain(Rabbit rabbit)
    {
        IsJumpChainActive = true;
        jumpChainRabbit = rabbit;
    }

    public void EndJumpChain()
    {
        IsJumpChainActive = false;
        jumpChainRabbit = null;
    }

    public bool IsInJumpChain(Rabbit rabbit)
    {
        return IsJumpChainActive && rabbit == jumpChainRabbit;
    }

    public void EndTurnManually()
    {
        if (IsJumpChainActive)
        {
            EndJumpChain();
            SwitchTurn();
        }
    }

    public bool CheckWinCondition(Team team)
    {
        Vector2Int center = (team == Team.White) ? blackStartCenter : whiteStartCenter;
        return IsSquareFormation(team, center);
    }

    private bool IsSquareFormation(Team team, Vector2Int center)
    {
        for (int dx = -1; dx <= 1; dx++)
        {
            for (int dy = -1; dy <= 1; dy++)
            {
                Vector2Int p = center + new Vector2Int(dx, dy);
                if (!gridManager.IsWithinBounds(p)) return false;

                var go = gridManager.GetObject(p); // ← gridManager에 이 메서드가 없다면, 네가 쓰던 방식으로 대체
                if (dx == 0 && dy == 0)
                {
                    // 중앙: 반드시 같은 팀의 KingRabbit
                    if (go == null) return false;
                    var kr = go.GetComponent<KingRabbit>()
                          ?? go.GetComponentInChildren<KingRabbit>()
                          ?? go.GetComponentInParent<KingRabbit>();
                    if (kr == null || kr.team != team) return false;
                }
                else
                {
                    // 주변 8칸: 같은 팀의 어떤 Rabbit(왕 제외해도 되고 포함해도 되면 조건 완화)
                    if (go == null) return false;
                    var rb = go.GetComponent<Rabbit>()
                           ?? go.GetComponentInChildren<Rabbit>()
                           ?? go.GetComponentInParent<Rabbit>();
                    if (rb == null || rb.team != team) return false;
                    if (rb.GetComponent<KingRabbit>() != null) return false;
                }
            }
        }
        return true;
    }

    public void CheckVictoryAfterTurn()
    {
        if (isGameOver) return;

        if (!kingRabbitWhite || !kingRabbitBlack) RefreshKings(); // 방어적 보강

        if (CheckWinCondition(Team.White)) { EndGame(Team.White); return; }
        if (CheckWinCondition(Team.Black)) { EndGame(Team.Black); return; }
    }

    public void EndGame(Team winningTeam)
    {
        if (isGameOver) return;
    isGameOver = true;
    Time.timeScale = 0f;

    // UI 찾기 안전화: 비활성 포함
#if UNITY_600_OR_NEWER
    var ui = FindFirstObjectByType<TurnControlUI>(FindObjectsInactive.Include);
#else
    var ui = FindObjectOfType<TurnControlUI>(true); // Unity 2021+ 오버로드
#endif
    if (ui != null) ui.ShowWinPanel(winningTeam);
    else Debug.LogWarning("TurnControlUI를 찾을 수 없어 GameOver 패널을 표시하지 못했습니다.");
    }
}
